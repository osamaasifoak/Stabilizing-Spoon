class AssetConstant {
  static const String splash = 'assets/splash.png';
  static const String onboarding_1 = 'assets/on-boarding-1.png';
  static const String onboarding_2 = 'assets/on-boarding-2.png';
  static const String onboarding_3 = 'assets/on-boarding-3.png';
  static const String hanging_short = 'assets/hanging-short.webp';
  static const String booking = 'assets/booking.svg';
  static const String bookingSelected = 'assets/booking-s.svg';
  static const String home = 'assets/home.svg';
  static const String homeSelected = 'assets/home-s.svg';
  static const String message = 'assets/message.svg';
  static const String messageSelected = 'assets/message-s.svg';
  static const String more = 'assets/more.svg';
  static const String moreSelected = 'assets/more-s.svg';
  static const String flash = 'assets/flash.svg';
  static const String waterHeater = 'assets/water-heater.svg';
  static const String moneyService = 'assets/money-service.svg';
  static const String bookingDate = 'assets/booking-date.svg';
  static const String bookingTime = 'assets/booking-time.svg';
  static const String happyPana = 'assets/happy-pana.png';
}
