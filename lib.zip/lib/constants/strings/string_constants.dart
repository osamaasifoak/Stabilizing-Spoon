class StringConstant {
  static const String react = "Stable Spoon";
  static const String eatingPartner = "You're eating partner";
  static const String onboarding_1 =
      "Now don’t be sad about how to eat with your shaking hand.";
  static const String onboarding_2 =
      "We are here to help you because  we understand your problem.";
  static const String onboarding_3 =
      "We are here to maintain your record, So check your stats on one click.";
  static const String login = "Login";
  static const String selectDate = "Select date";
  static const String saveChanges = "Save Changes";
  static const String signup = "Sign Up";
  static const String email = "Email";
  static const String password = "Password";
  static const String resetPassword = "Reset Password";
  static const String forgotPassword = "Forgot Password?";
  static const String continueText = "Continue";
  static const String cart = "Cart";
  static const String gettingStarted = "Get Started";
  static const String fullName = "Full Name";
  static const String currencyName = "Rs.";
  static const String mobileNumber = "Mobile Number";
  static const String otpVerification = "OTP Verification";
  static const String pleaseEnterOtpCode = "Please Enter OTP Code";
  static const String checkOtp =
      "We have sent you an OTP Code on your Following\n03xx xxxx628 Mobile Number";
  static const String resendOTP = "Resend OTP";
  static const String verify = "Verify";
  static const String home = "Home";
  static const String bookings = "Bookings";
  static const String live = "live stats";
  static const String messages = "Messages";
  static const String more = "More";
  static const String servicesInclude = "Services Includes";
  static const String serviceAdd = "Add";
  static const String servicesAdded = "Added";
  static const String selectedServices = "Selected Services";
  static const String totalBillAmount = "Total Billing Amount";
  static const String next = "Next";
  static const String removeFromOrder = "Remove from Order";
  static const String upcoming = "Upcoming";
  static const String completed = "Completed";
  static const String timeDate = "Time & Date";
  static const String orderStatus = "Order Status";
  static const String memberSince = "Member Since:";
  static const String workerDetail = "Worker Detail";
  static const String bookingDetail = "Booking Detail";
  static const String reviews = "Reviews";
}
